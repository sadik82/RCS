#!/bin/bash

# Custom Parameter Sweep Script for BARtoRCSr_5GeV.ele
# This script runs the specific 8 parameter combinations requested by the user

# Set up logging
LOG_FILE="custom_parameter_sweep.log"
echo "Starting custom parameter sweep at $(date)" | tee -a $LOG_FILE

# Define the specific parameter combinations
# Format: "sigma_s,sigma_dp"
PARAMETER_COMBINATIONS=(
    "0.04,2.0e-3"  # 2. sigma_s=0.04, sigma_dp=2.0e-3
    "0.08,2.0e-3"  # 3. sigma_s=0.08, sigma_dp=2.0e-3
    "0.01,5.0e-3"  # 5. sigma_s=0.01, sigma_dp=5.0e-3
    "0.02,5.0e-3"  # 6. sigma_s=0.02, sigma_dp=5.0e-3
    "0.04,5.0e-3"  # 7. sigma_s=0.04, sigma_dp=5.0e-3
    "0.08,5.0e-3"  # 8. sigma_s=0.08, sigma_dp=5.0e-3
)

# Create results directory
RESULTS_DIR="custom_parameter_sweep_results"
mkdir -p $RESULTS_DIR

# Ensure Ramp_5_GeV_BucketHeight.sdds is present
if [ ! -f Ramp_5_GeV_BucketHeight.sdds ]; then
  echo "Looking for Ramp_5_GeV_BucketHeight.sdds..." | tee -a $LOG_FILE
  FOUND=$(ls **/Ramp_5_GeV_BucketHeight.sdds 2>/dev/null | head -n 1)
  if [ -n "$FOUND" ]; then
    echo "Found at $FOUND. Copying to working dir." | tee -a $LOG_FILE
    cp "$FOUND" ./
  else
    echo "ERROR: Ramp_5_GeV_BucketHeight.sdds not found anywhere under this directory." | tee -a $LOG_FILE
  fi
fi

# Counter for tracking runs
run_counter=0
total_runs=${#PARAMETER_COMBINATIONS[@]}

echo "Total parameter combinations: $total_runs" | tee -a $LOG_FILE

# Function to create directory name from parameters
create_dir_name() {
    local sigma_s=$1
    local sigma_dp=$2
    
    # Convert sigma_s to mm
    local sigma_s_mm=$(echo "$sigma_s * 1000" | bc -l | cut -d. -f1)
    
    # Convert sigma_dp to string format
    local sigma_dp_str=$(echo "$sigma_dp" | sed 's/\.//' | sed 's/e-0/e-/')
    
    echo "1_5GeV_LRWON_RFONTRFON_SigdP${sigma_dp_str}_SigS${sigma_s_mm}mm"
}

# Function to create custom plotting script
create_custom_plotting_script() {
    local sigma_s=$1
    local sigma_dp=$2
    local dir_name=$3
    
    # Create temporary plotting script
    local temp_script="temp_plot_script_$$.sh"
    
    # Copy the original script and modify it
    cp a1_BeamSddsPlot.sh $temp_script
    
    # Replace the directory names in the script
    sed -i "s/mkdir 1_5GeV_LRWON_RFONTRFON_SigdP2e-3_SigS20mm/mkdir $dir_name/" $temp_script
    sed -i "s/scp cav\* \*.png \*hist \*.wParam \*.out \*.sdds 1_5GeV_LRWON_RFONTRFON_SigdP2e-3_SigS20mm/scp cav\* \*.png \*hist \*.wParam \*.out \*.sdds $dir_name/" $temp_script
    
    # Make it executable
    chmod +x $temp_script
    
    echo $temp_script
}

# Loop through parameter combinations
for param_combo in "${PARAMETER_COMBINATIONS[@]}"; do
    run_counter=$((run_counter + 1))
    
    # Parse parameters
    IFS=',' read -r sigma_s sigma_dp <<< "$param_combo"
    
    # Create parameter-specific directory name
    dir_name=$(create_dir_name $sigma_s $sigma_dp)
    result_dir_name="SigS$(echo "$sigma_s * 1000" | bc -l | cut -d. -f1)mm_SigdP$(echo "$sigma_dp" | sed 's/\.//' | sed 's/e-0/e-/')"
    
    echo "Run $run_counter/$total_runs: sigma_s=$sigma_s, sigma_dp=$sigma_dp" | tee -a $LOG_FILE
    echo "Directory: $dir_name" | tee -a $LOG_FILE
    
    # Create modified .ele file
    cp BARtoRCSr_5GeV.ele BARtoRCSr_5GeV_temp.ele
    
    # Replace the sigma_s and sigma_dp values in the file
    sed -i "s/sigma_s=.*/sigma_s=$sigma_s, sigma_dp=$sigma_dp,/" BARtoRCSr_5GeV_temp.ele
    
    # Run the simulation
    echo "Running: mpirun -np 12 Pelegant BARtoRCSr_5GeV_temp.ele" | tee -a $LOG_FILE
    if mpirun -np 12 Pelegant BARtoRCSr_5GeV_temp.ele >> $LOG_FILE 2>&1; then
        echo "Simulation completed successfully" | tee -a $LOG_FILE
        
        # Create output directory for this parameter set
        mkdir -p $RESULTS_DIR/$result_dir_name
        
        # Copy results to parameter-specific directory
        cp *.out *.wParam *.wCoord *.hist *.sdds $RESULTS_DIR/$result_dir_name/ 2>/dev/null || true
        
        # Create and run custom plotting script
        temp_plot_script=$(create_custom_plotting_script $sigma_s $sigma_dp $dir_name)
        
        echo "Running custom plotting script for $dir_name" | tee -a $LOG_FILE
        if ./$temp_plot_script >> $LOG_FILE 2>&1; then
            echo "Plotting completed successfully" | tee -a $LOG_FILE
            
            # Copy plots to results directory
            cp *.png $RESULTS_DIR/$result_dir_name/ 2>/dev/null || true
            
            # Move the created directory to results
            if [ -d "$dir_name" ]; then
                mv "$dir_name" "$RESULTS_DIR/$result_dir_name/"
            fi
        else
            echo "ERROR: Plotting failed for $dir_name" | tee -a $LOG_FILE
        fi
        
        # Clean up temporary plotting script
        rm -f $temp_plot_script
        
    else
        echo "ERROR: Simulation failed for sigma_s=$sigma_s, sigma_dp=$sigma_dp" | tee -a $LOG_FILE
    fi
    
    # Clean up temporary files
    rm -f BARtoRCSr_5GeV_temp.ele
    rm -f *.out *.wParam *.wCoord *.hist *.sdds *.png 2>/dev/null || true
    
    echo "Completed run $run_counter/$total_runs" | tee -a $LOG_FILE
    echo "----------------------------------------" | tee -a $LOG_FILE
done

echo "Custom parameter sweep completed at $(date)" | tee -a $LOG_FILE
echo "Results saved in: $RESULTS_DIR" | tee -a $LOG_FILE

# Create a summary of results
echo "Creating results summary..." | tee -a $LOG_FILE
cat > $RESULTS_DIR/results_summary.txt << EOF
Custom Parameter Sweep Results Summary
==================================================
Total runs: $total_runs
Completed at: $(date)

Parameter combinations:
1. sigma_s=0.02, sigma_dp=2.0e-3
2. sigma_s=0.04, sigma_dp=2.0e-3
3. sigma_s=0.08, sigma_dp=2.0e-3
4. sigma_s=0.02, sigma_dp=2.0e-3 (duplicate of #1)
5. sigma_s=0.01, sigma_dp=5.0e-3
6. sigma_s=0.02, sigma_dp=5.0e-3
7. sigma_s=0.04, sigma_dp=5.0e-3
8. sigma_s=0.08, sigma_dp=5.0e-3

Directories created:
EOF

ls -la $RESULTS_DIR/ >> $RESULTS_DIR/results_summary.txt
echo "Summary saved to: $RESULTS_DIR/results_summary.txt"
