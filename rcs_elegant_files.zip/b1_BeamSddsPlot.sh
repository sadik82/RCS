#!/bin/bash
rm *.png

sddsplot BARtoRCSr_10GeV.wParam \
  -layout=3,3 \
  -col=Pass,pAverage -newPanel=1,1 \
  -col=Pass,Cx -legend=specified="x" -newPanel=1,2 -col=Pass,Cy -legend=specified="y" -graphic=line,type=1 \
  -col=Pass,Cxp -legend=specified="x" -newPanel=1,3 -col=Pass,Cyp -legend=specified="y" -graphic=line,type=1 \
  -col=Pass,ex -newPanel=2,1 -col=Pass,ey -graphic=line,type=1 \
  -col=Pass,Sxp -legend=specified="x" -newPanel=2,2 -col=Pass,Syp -legend=specified="y" -graphic=line,type=1 \
  -col=Pass,Sx -legend=specified="x" -newPanel=2,3 -col=Pass,Sy -legend=specified="y" -graphic=line,type=1 \
  -col=Pass,Ss -newPanel=3,1 \
  -col=Pass,Cdelta -newPanel=3,2 \
  -col=Pass,Sdelta -newPanel=3,3 \
  -device=png -output=4_wParam.png

  sddsplot BARtoRCSr_10GeV.wParam -col=Pass,Cx -legend=specified="x" -col=Pass,Cy -legend=specified="y" -graphic=line,type=1 -device=png -output=3_RCS_CxCy.png
  sddsplot BARtoRCSr_10GeV.wParam -col=Pass,Cxp -legend=specified="x" -col=Pass,Cyp -legend=specified="y" -graphic=line,type=1 -device=png -output=3_RCS_CxpCyp.png
  sddsplot BARtoRCSr_10GeV.wParam -col=Pass,ex -newPanel=2,1 -col=Pass,ey -graphic=line,type=1 -device=png -output=3_RCS_exey.png
  sddsplot BARtoRCSr_10GeV.wParam -col=Pass,Sxp -legend=specified="x" -col=Pass,Syp -legend=specified="y" -graphic=line,type=1 -device=png -output=3_RCS_SxpSyp.png
  sddsplot BARtoRCSr_10GeV.wParam -col=Pass,Sx -legend=specified="x" -col=Pass,Sy -legend=specified="y" -graphic=line,type=1 -device=png -output=3_RCS_SxSy.png
  sddsplot BARtoRCSr_10GeV.wParam -col=Pass,Ss -newPanel=3,1 -device=png -output=3_RCS_Ss.png
  sddsplot BARtoRCSr_10GeV.wParam -col=Pass,Cdelta -newPanel=3,2 -device=png -output=3_RCS_Cdelta.png
  sddsplot BARtoRCSr_10GeV.wParam -col=Pass,Sdelta -newPanel=3,3 -device=png -output=3_RCS_Sdelta.png


sddsplot BARtoRCSr_10GeV.wParam \
  -layout=3,2 \
  -col=Pass,Cx -legend=specified="x" -newPanel=1,1 -col=Pass,Cy -legend=specified="y" -graphic=line,type=1 \
  -col=Pass,ex -newPanel=1,2 -col=Pass,ey -graphic=line,type=1 \
  -col=Pass,Sx -legend=specified="x" -newPanel=2,1 -col=Pass,Sy -legend=specified="y" -graphic=line,type=1 \
  -col=Pass,Ss -newPanel=2,2 \
  -col=Pass,Cdelta -newPanel=3,1 \
  -col=Pass,Sdelta -newPanel=3,1 \
  -device=png -output=5_wParam.png

sddsplot BARtoRCSr_10GeV.wParam -col=Pass,Particles -device=png -output=2_ParticleLoss.png
sddsanalyzebeam BARtoRCSr_10GeV.wCoord BARtoRCSr_10GeV_Ana.sdds
sddsplot -col=Pass,el BARtoRCSr_10GeV_Ana.sdds -device=png -output=3_LongEmittance_elvsPass.png
./a3_AllCavAllMod_sddsplot.sh
./a5_AllCavAllTMod_sddsplot.sh

#mkdir 1_10GeV_SigdP2e-3_SigS5mm
#scp cav* *.png *hist *.wParam *.out *.sdds 1_10GeV_SigdP2e-3_SigS5mm

#mkdir 1_10GeV_SigdP5e-4_SigS20mm
#scp cav* *.png *hist *.wParam *.out *.sdds 1_10GeV_SigdP5e-4_SigS20mm

mkdir 1_10GeV_LWON_SigdP5e-4_SigS20mm
scp cav* *.png *hist *.wParam *.out *.sdds 1_10GeV_LWON_SigdP5e-4_SigS20mm

#mkdir 1_10GeV_SigdP5e-4_SigS5mm
#scp cav* *.png *hist *.wParam *.out *.sdds 1_10GeV_SigdP5e-4_SigS5mm



#mkdir 1_ShortRangeOnly_Wx8Cavs
#scp cav* *.png *hist *.wParam *.out *.sdds 1_ShortRangeOnly_Wx8Cavs

#mkdir 1_5GeV_NoHOM_WFM
#scp cav* *.png *hist *.wParam *.out *.sdds 1_5GeV_NoHOM_WFM

#mkdir 1_ShortRangeOnly_Wz4Cavs
#scp cav* *.png *hist *.wParam *.out *.sdds 1_ShortRangeOnly_Wz4Cavs

#mkdir 1_5GeV_TRFMQL4e3
#scp cav* *.png *hist *.wParam *.out *.sdds 1_5GeV_TRFMQL4e3

#mkdir 1_5GeV_TRFMQL2e3
#scp cav* *.png *hist *.wParam *.out *.sdds 1_5GeV_TRFMQL2e3

#./b_VHOM_sddsplot.sh  
# sddsplot RfRamp.sdds -column=time,Voltage -graph=line,primary -color=red RfRamp.sdds -column=time,Voltage -graph=line,secondary -color=blue -scale=0,0,0,0,0,0,0,0 -split=page -separate=page
  
# sddsplot RfRamp.sdds -columnNames=time,Voltage -graph=line,vary -legend -columnNames=time,Phase -graph=line,vary -scale=0,0,0,0,0,0,0,0 -split=page -separate=page -yScalesGroup=id=Phase -legend