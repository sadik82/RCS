sddsplot \
-column=Pass,VPostBeam 2_FDetune_df0Hz_24kPass/mode1.sdds -graph=line,vary -legend=spec="$delta$ f: 0 Hz" \
-column=Pass,VPostBeam 2_FDetune_dfn100Hz_24kPass/mode1.sdds -graph=line,vary  -legend=spec="\DELTA_f: 100 Hz" \
-device=png -output=0_compare/2_RCS591MHz_VPostBeam.png

sddsprintout 2_FDetune_df0Hz_24kPass/mode1.sdds -col=VPostBeam > 2_FDetune_df0Hz_24kPass/mode1_0Hz.txt
sddsprintout 2_FDetune_dfn100Hz_24kPass/mode1.sdds -col=VPostBeam > 2_FDetune_dfn100Hz_24kPass/mode1_100Hz.txt

python3 << EOF
import matplotlib.pyplot as plt
import numpy as np

def load_data_fast(filename):
    try:
        # Try to load with numpy first (much faster)
        data = np.loadtxt(filename, skiprows=1)  # Skip header
        return data
    except:
        # Fallback to manual parsing if needed
        with open(filename, 'r') as f:
            lines = f.readlines()
        start = False
        data = []
        for line in lines:
            if '---------------' in line:
                start = True
                continue
            if start:
                stripped = line.strip()
                if stripped:
                    try:
                        data.append(float(stripped))
                    except ValueError:
                        pass
        return np.array(data)

print("Loading data...")
data0 = load_data_fast('2_FDetune_df0Hz_24kPass/mode1_0Hz.txt')
data100 = load_data_fast('2_FDetune_dfn100Hz_24kPass/mode1_100Hz.txt')

print(f"Data loaded: {len(data0)} points for 0Hz, {len(data100)} points for 100Hz")

if len(data0) != len(data100):
    print("Warning: Datasets have different lengths.")
    min_len = min(len(data0), len(data100))
    data0 = data0[:min_len]
    data100 = data100[:min_len]

passes = np.arange(1, len(data0) + 1)

print("Creating plot...")
plt.figure(figsize=(10, 6))
plt.plot(passes, data0, label=r'$\Delta f$: 0 Hz', linewidth=1)
plt.plot(passes, data100, label=r'$\Delta f$: 100 Hz', linewidth=1)
plt.xlabel('Pass')
plt.ylabel('VPostBeam (V)')
plt.title('VPostBeam vs Pass')
plt.legend()
plt.grid(True, alpha=0.3)
plt.savefig('0_compare/2_RCS591MHz_VPostBeam_from_txt.png', dpi=150, bbox_inches='tight')
plt.close()
print("Plot saved successfully!")
EOF