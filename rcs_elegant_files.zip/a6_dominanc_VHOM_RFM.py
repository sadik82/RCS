#!/usr/bin/env python3
import argparse, os, subprocess
from datetime import datetime
import numpy as np
from typing import Tuple, List, Optional

def run_command(working_dir: str, command: str) -> Optional[str]:
    result = subprocess.run(command, shell=True, capture_output=True, text=True, cwd=working_dir)
    if result.returncode != 0:
        print(f"--- ERROR ---\nCommand failed: '{command}'\nIn directory: '{working_dir}'\nStderr: {result.stderr.strip()}\nStdout: {result.stdout.strip()}\n-------------")
        return None
    return result.stdout

def parse_vx_vy(text: str) -> Tuple[np.ndarray, np.ndarray]:
    words = text.strip().split()
    vals: List[float] = []
    for w in words:
        try: vals.append(float(w))
        except ValueError: pass
    if len(vals) < 2: return np.array([]), np.array([])
    arr = np.array(vals, dtype=float)
    n2 = (len(arr)//2)*2
    arr = arr[:n2].reshape(-1, 2)
    return arr[:,0], arr[:,1]

def magnitude(vx: np.ndarray, vy: np.ndarray) -> np.ndarray:
    return np.sqrt(vx*vx + vy*vy)

def dominance_score(vx: np.ndarray, vy: np.ndarray, metric: str) -> float:
    if vx.size == 0: return 0.0
    mag = magnitude(vx, vy)
    if metric == "rms":  return float(np.sqrt(np.mean(mag*mag)))
    if metric == "peak": return float(np.max(mag))
    if metric == "last": return float(mag[-1])
    raise ValueError(f"Unknown metric: {metric}")

# --- NEW: component-wise summary matching the selected metric ---
def _summarize(arr: np.ndarray, metric: str) -> float:
    if arr.size == 0: return 0.0
    if metric == "rms":  return float(np.sqrt(np.mean(arr*arr)))
    if metric == "peak": return float(np.max(np.abs(arr)))
    if metric == "last": return float(abs(arr[-1]))
    raise ValueError(f"Unknown metric: {metric}")

# --- NEW: 0° if horizontal (Vx dominates), 90° if vertical (Vy dominates)
def polarity_deg(vx: np.ndarray, vy: np.ndarray, metric: str) -> int:
    mx = _summarize(vx, metric)
    my = _summarize(vy, metric)
    return 0 if mx >= my else 90

def process_run_dir(run_dir: str, file_template: str, num_lines: int, metric: str) -> None:
    if not os.path.isdir(run_dir):
        print(f"[WARN] Skipping '{run_dir}' (not a directory).")
        return

    out_name = f"HOM_mode_dominance_last{num_lines}_{metric}.txt"
    out_path = os.path.join(run_dir, out_name)

    lines_out: List[str] = []
    lines_out += [
        "# HOM Mode Dominance Report",
        f"# Run directory : {run_dir}",
        f"# File template : {file_template}",
        f"# Lines used    : last {num_lines}",
        f"# Metric        : {metric} (rms | peak | last)",
        "# Polarity      : 0°=horizontal (Vx-dominant), 90°=vertical (Vy-dominant)",
        f"# Generated     : {datetime.now().isoformat(timespec='seconds')}",
        ""
    ]

    print(f"\nProcessing: {run_dir}")
    print(f"  -> collecting last {num_lines} lines per mode using metric = {metric}")

    for cav in range(1, 9):
        per_cavity: List[Tuple[int, float, int]] = []

        for mode in range(1, 101):
            sdds_name = file_template.format(c=cav, m=mode)
            sdds_path = os.path.join(run_dir, sdds_name)
            if not os.path.isfile(sdds_path):
                continue

            cmd = f"sddsprintout {sdds_name} -col=Vx -col=Vy | tail -n {num_lines}"
            txt = run_command(run_dir, cmd)
            if txt is None or not txt.strip():
                continue

            vx, vy = parse_vx_vy(txt)
            if vx.size == 0:
                continue

            score = dominance_score(vx, vy, metric)
            pol = polarity_deg(vx, vy, metric)    # NEW
            per_cavity.append((mode, score, pol)) # UPDATED

        per_cavity.sort(key=lambda t: t[1], reverse=True)

        # UPDATED header with Pol(deg)
        lines_out.append(f"Cavity {cav}: mode dominance (descending) — metric={metric}, last{num_lines} lines")
        lines_out.append("Rank  Mode      Score            Pol(deg)")
        lines_out.append("-----------------------------------------")
        for rank, (mode, score, pol) in enumerate(per_cavity, start=1):
            lines_out.append(f"{rank:>4}  {mode:>4}  {score:>14.6e}      {pol:>3d}")
        lines_out.append("")

        # Console preview: Top 10 with polarity
        preview_n = min(10, len(per_cavity))
        if preview_n > 0:
            print(f"  Cavity {cav} — Top {preview_n} modes:")
            for r in range(preview_n):
                mode, score, pol = per_cavity[r]
                print(f"    #{r+1:>2}: mode {mode:>3}  score={score:.6e}  pol={pol}°")
        else:
            print(f"  Cavity {cav}: no modes found.")

    with open(out_path, "w") as f:
        f.write("\n".join(lines_out))
    print(f"\nSaved: {out_path}")

def main():
    ap = argparse.ArgumentParser(description="Rank HOM modes per cavity from SDDS Vx/Vy; includes polarity (0°=H, 90°=V).")
    ap.add_argument("run_dirs", nargs="+", help="Run directories (e.g. 1_5GeV_TRFMQL1e5).")
    ap.add_argument("--num-lines", type=int, default=100, help="Trailing lines to use per mode (default: 100).")
    ap.add_argument("--metric", choices=["rms", "peak", "last"], default="rms", help="Dominance metric.")
    ap.add_argument("--file-template", default="C{c}TM{m}.sdds", help="Filename template, e.g. 'C{c}TM{m}.sdds' or 'cav{c}mod{m}.sdds'.")
    args = ap.parse_args()
    for rd in args.run_dirs:
        process_run_dir(rd, args.file_template, args.num_lines, args.metric)

if __name__ == "__main__":
    main()
