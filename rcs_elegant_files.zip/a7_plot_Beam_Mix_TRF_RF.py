import subprocess
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

mpl.rcParams.update({
    'axes.titlesize': 18,
    'axes.labelsize': 18,
    'xtick.labelsize': 18,
    'ytick.labelsize': 18,
    'legend.fontsize': 18,
    'figure.constrained_layout.use': True,
})

def run_command(working_dir, command):
    """Executes a local command in a specified directory and returns the output."""
    result = subprocess.run(command, shell=True, capture_output=True, text=True, cwd=working_dir)
    if result.returncode != 0:
        print(f"--- ERROR ---")
        print(f"Command failed: '{command}'")
        print(f"In directory: '{working_dir}'")
        print(f"Stderr: {result.stderr}")
        print(f"Stdout: {result.stdout}")
        print(f"-------------")
        return None
    return result.stdout

def main():
    linux_dir = os.getcwd() 
    output_dir = '0_compare_Mix'
    os.makedirs(output_dir, exist_ok=True)
    print(f"Working directory set to: {linux_dir}")
    print(f"Output will be saved to: {output_dir}")
    
    detune_configs = [
        {'suffix': '_NoHOM_NoFM', 'label': 'FM Only'},
        {'suffix': '_Mix_RFQL1e5_TRFMQL4e3', 'label': '$Q_{L, RF}=1e5~&~Q_{L, TRF}=1e3$'}
    ]
    
    colors = ['b', 'r', 'g', 'm', 'c', 'k','darkorange', 'gold', 'slategray', 'indigo', 'dodgerblue', 'deepskyblue']

    # Figures (voltage removed)
    fig2, ax2 = plt.subplots(figsize=(7, 5)) # Emittance
    fig3, ax3 = plt.subplots(figsize=(7, 5)) # Centroid X
    fig3b, ax3b = plt.subplots(figsize=(7, 5)) # Centroid Y
    fig4, ax4 = plt.subplots(figsize=(7, 5)) # Beam Size
    fig5, ax5 = plt.subplots(figsize=(7, 5)) # Bunch Length
    fig6, ax6 = plt.subplots(figsize=(7, 5)) # Particles
    fig7, ax7 = plt.subplots(figsize=(7, 5)) # Momentum Spread

    for i, config in enumerate(detune_configs):
        print(f"Processing configuration: {config['label']}...")
        
        sdds_file2 = f"1_5GeV{config['suffix']}/BARtoRCSr_5GeV.wParam"
        cols = "-col=ex -col=ey -col=Cx -col=Cy -col=Sx -col=Sy -col=Ss -col=Sdelta -col=Particles"
        cmd2 = f"sddsprintout {sdds_file2} {cols}"

        b_output = run_command(linux_dir, cmd2)
        if b_output is None:
            print(f"Skipping configuration '{config['label']}' due to a command error.")
            continue

        try:
            b_lines = b_output.strip().split('\n')
            b_data_list = []
            current_row = []
            for line in b_lines:
                for word in line.strip().split():
                    try:
                        current_row.append(float(word))
                    except ValueError:
                        continue
                while len(current_row) >= 9:
                    b_data_list.append(current_row[:9])
                    current_row = current_row[9:]
            b_data = np.array(b_data_list)
            if b_data.size == 0:
                print(f"No valid data for {config['label']}.")
                continue
        except Exception as e:
            print(f"Parsing error for {config['label']}: {e}")
            continue

        num_points = len(b_data)
        passes = np.arange(1, num_points + 1)

        ex = b_data[:, 0]
        ey = b_data[:, 1]
        Cx = b_data[:, 2]
        Cy = b_data[:, 3]
        Sx = b_data[:, 4]
        Sy = b_data[:, 5]
        Ss = b_data[:, 6]
        Sdelta = b_data[:, 7]
        Particles = b_data[:, 8]

        ax2.plot(passes, ex*1e6, color=colors[i], linestyle='-', linewidth=1.5, label=f"$\\epsilon_x$, {config['label']}")
        ax2.plot(passes, ey*1e6, color=colors[i], linestyle='--', linewidth=1.5, label=f"$\\epsilon_y$, {config['label']}")

        ax3.plot(passes, Cx*1e6, color=colors[i], linestyle='-', linewidth=1.5, label=f"$C_x$, {config['label']}")
        ax3b.plot(passes, Cy*1e6, color=colors[i], linestyle='--', linewidth=1.5, label=f"$C_y$, {config['label']}")

        ax4.plot(passes, Sx*1e3, color=colors[i], linestyle='-', linewidth=1.5, label=f"$\\sigma_x$, {config['label']}")
        ax4.plot(passes, Sy*1e3, color=colors[i], linestyle='--', linewidth=1.5, label=f"$\\sigma_y$, {config['label']}")

        ax5.plot(passes, Ss*1e3, color=colors[i], linestyle='-', linewidth=1.5, label=f"$\\sigma_s$, {config['label']}")
        ax6.plot(passes, Particles, color=colors[i], linestyle='-', linewidth=1.5, label=f"{config['label']}")
        ax7.plot(passes, Sdelta*1e3, color=colors[i], linestyle='-', linewidth=1.5, label=f"$\\delta$, {config['label']}")

    # Finalize figures
    ax2.set_title('Emittance vs Pass'); ax2.set_xlabel('Pass'); ax2.set_ylabel('Emittance ($\mu$m-rad)')
    ax2.legend(); fig2.savefig(os.path.join(output_dir, '2Emittance_Comparison.png'))

    ax3.set_title('Centroid vs Pass'); ax3.set_xlabel('Pass'); ax3.set_ylabel('Centroid ($\mu$m)')
    ax3.legend(); fig3.savefig(os.path.join(output_dir, '3Centroid_Comparison_x.png'))

    ax3b.set_title('Centroid vs Pass'); ax3b.set_xlabel('Pass'); ax3b.set_ylabel('Centroid ($\mu$m)')
    ax3b.legend(); fig3b.savefig(os.path.join(output_dir, '3Centroid_Comparison_y.png'))

    ax4.set_title('Beam Size vs Pass'); ax4.set_xlabel('Pass'); ax4.set_ylabel(r'Beam Size ($\sigma$) (mm)')
    ax4.legend(); fig4.savefig(os.path.join(output_dir, '4BeamSize_Comparison.png'))

    ax5.set_title('Bunch Length vs Pass'); ax5.set_xlabel('Pass'); ax5.set_ylabel(r'Bunch Length ($\sigma_s$) (mm)')
    ax5.legend(); fig5.savefig(os.path.join(output_dir, '5BunchLength_Comparison.png'))
    
    ax6.set_title('Particles vs Pass'); ax6.set_xlabel('Pass'); ax6.set_ylabel('Number of Particles')
    ax6.legend(); fig6.savefig(os.path.join(output_dir, '6Particles_Comparison.png'))

    ax7.set_title('Momentum Spread vs Pass'); ax7.set_xlabel('Pass'); ax7.set_ylabel(r'Momentum Spread ($\delta \times 10^3$)')
    ax7.legend(); fig7.savefig(os.path.join(output_dir, '7MomentumSpread_Comparison.png'))

    plt.show()

if __name__ == "__main__":
    main()
