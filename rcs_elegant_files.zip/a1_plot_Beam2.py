import subprocess
import os
import numpy as np
import matplotlib.pyplot as plt
import io
import re

import matplotlib as mpl

import matplotlib as mpl
mpl.rcParams.update({
    'axes.titlesize': 18,
    'axes.labelsize': 18,
    'xtick.labelsize': 18,
    'ytick.labelsize': 18,
    'legend.fontsize': 18,
    'figure.constrained_layout.use': True,   # <-- key line
})



def run_command(working_dir, command):
    """Executes a local command in a specified directory and returns the output."""
    # Execute the command directly.
    # The 'cwd' argument changes the directory before running the command.
    # 'shell=True' is used to correctly interpret the command string with its arguments.
    result = subprocess.run(command, shell=True, capture_output=True, text=True, cwd=working_dir)
    
    # Check for errors
    if result.returncode != 0:
        print(f"--- ERROR ---")
        print(f"Command failed: '{command}'")
        print(f"In directory: '{working_dir}'")
        print(f"Stderr: {result.stderr}")
        print(f"Stdout: {result.stdout}")
        print(f"-------------")
        return None
        
    return result.stdout

def main():
    """
    Main function to execute the data processing and plotting.
    """
    # --- Configuration ---
    # This is the directory where the script is running, which is the correct top-level directory.
    linux_dir = os.getcwd() 
    output_dir = '0_compare_SigdP1e-3'
    os.makedirs(output_dir, exist_ok=True) # Create the output directory if it doesn't exist
    print(f"Working directory set to: {linux_dir}")
    print(f"Output will be saved to: {output_dir}")
    
    # Detune configurations (similar to the MATLAB struct)
    detune_configs = [
        {'suffix': 'SigS80mm', 'label': '80 mm'},
        {'suffix': 'SigS70mm', 'label': '70 mm'},
        {'suffix': 'SigS60mm', 'label': '60 mm'},
        {'suffix': 'SigS50mm', 'label': '50 mm'},
        {'suffix': 'SigS40mm', 'label': '40 mm'},
        {'suffix': 'SigS30mm', 'label': '30 mm'},
        {'suffix': 'SigS20mm', 'label': '20 mm'},
        {'suffix': 'SigS10mm', 'label': '10 mm'},
        {'suffix': 'SigS5mm', 'label': '5 mm'}
#        {'suffix': 'SigS9p7mm', 'label': '9.7 mm'}
#        {'suffix': '_NoHOM_NoFM', 'label': 'W/O FM & HOM'}
]
    
    colors = ['b', 'r', 'g', 'm', 'c', 'k','darkorange', 'gold', 'slategray', 'indigo', 'dodgerblue', 'deepskyblue']
    #colors = ['k', 'slategray','b', 'dodgerblue', 'c', 'teal', 'r', 'darkorange', 'gold','brown','olive', 'g', 'm', 'indigo']
    #colors = ['k','b', 'c', 'r', 'gold', 'g', 'm', 'indigo', 'slategray', 'darkorange', 'dodgerblue','brown', 'teal','olive']

    # --- Create Figures ---
    fig1, ax1 = plt.subplots(figsize=(7, 5)) # VPostBeam
    fig2x, ax2x = plt.subplots(figsize=(7, 5)) # Emittance X
    fig2y, ax2y = plt.subplots(figsize=(7, 5)) # Emittance Y

    fig3x, ax3x = plt.subplots(figsize=(7, 5)) # Centroid X
    fig3y, ax3y = plt.subplots(figsize=(7, 5)) # Centroid Y

    fig4x, ax4x = plt.subplots(figsize=(7, 5)) # Beam Size X
    fig4y, ax4y = plt.subplots(figsize=(7, 5)) # Beam Size Y
    fig5, ax5 = plt.subplots(figsize=(7, 5)) # Bunch Length (Ss)
    fig6, ax6 = plt.subplots(figsize=(7, 5)) # Particles
    fig7, ax7 = plt.subplots(figsize=(7, 5)) # Momentum Spread (Sdelta)


    # --- Loop through configurations ---
    for i, config in enumerate(detune_configs):
        print(f"Processing configuration: {config['label']}...")
        
        # --- Command 1 for VPostBeam ---
        sdds_file1 = f"1_10GeV_SigdP1e-3_{config['suffix']}/cav1mod1.sdds"
        cmd1 = f"sddsprintout {sdds_file1} -col=VPostBeam"
        
        # --- Command 2 for Emittance and other parameters ---
        sdds_file2 = f"1_10GeV_SigdP1e-3_{config['suffix']}/BARtoRCSr_10GeV.wParam"
        cols = "-col=ex -col=ey -col=Cx -col=Cy -col=Sx -col=Sy -col=Ss -col=Sdelta -col=Particles"
        cmd2 = f"sddsprintout {sdds_file2} {cols}"

        # --- Execute commands and capture output ---
        v_output = run_command(linux_dir, cmd1)
        b_output = run_command(linux_dir, cmd2)

        if v_output is None or b_output is None:
            print(f"Skipping configuration '{config['label']}' due to a command error.")
            continue
            
        # --- Robust Parsing Logic ---
        try:
            # For single-column data, the simple parser is fine.
            v_lines = v_output.strip().split('\n')
            v_data_list = []
            for line in v_lines:
                try:
                    v_data_list.append(float(line.strip()))
                except ValueError:
                    continue
            v_data = np.array(v_data_list)

            # For multi-column data, safely try to convert words to numbers
            b_lines = b_output.strip().split('\n')
            b_data_list = []
            current_row = []
            for line in b_lines:
                # Split the line into words
                for word in line.strip().split():
                    try:
                        # Try to convert a word to a number and add it
                        current_row.append(float(word))
                    except ValueError:
                        # If it fails, just ignore the word (e.g., "Printout", "---")
                        continue
                
                # If we have collected a full row of 9, save it and reset
                while len(current_row) >= 9:
                    b_data_list.append(current_row[:9])
                    current_row = current_row[9:]
            
            b_data = np.array(b_data_list)

            # Check if any data was successfully parsed
            if v_data.size == 0 or b_data.size == 0:
                print(f"Could not parse any valid data lines for {config['label']}.")
                print("Please check if the sdds files exist and are not empty.")
                continue

        except Exception as e:
            print(f"An unexpected error occurred during parsing for {config['label']}. Error: {e}")
            continue

        # Extract columns for clarity
        # Ensure we don't try to plot more data than we have for passes
        num_points = min(len(v_data), len(b_data))
        # num_points = min(len(v_data), 1000)
        if num_points == 0: continue

        passes = np.arange(1, num_points + 1)
        V = v_data[:num_points]
        ex = b_data[:num_points, 0]
        ey = b_data[:num_points, 1]
        Cx = b_data[:num_points, 2]
        Cy = b_data[:num_points, 3]
        Sx = b_data[:num_points, 4]
        Sy = b_data[:num_points, 5]
        Ss = b_data[:num_points, 6]
        Sdelta = b_data[:num_points, 7]
        Particles = b_data[:num_points, 8]

        # --- Plotting ---
        ax1.plot(passes, V, color=colors[i], linestyle='-', linewidth=1.5, label=f"{config['label']}")
        
        # X-plane
        ax2x.plot(passes, ex*1e6, color=colors[i], linestyle='-',  linewidth=1.5, label=f"{config['label']}")
        ax3x.plot(passes, Cx*1e6, color=colors[i], linestyle='-',  linewidth=1.5, label=f"{config['label']}")
        ax4x.plot(passes, Sx*1e3, color=colors[i], linestyle='-',  linewidth=1.5, label=f"{config['label']}")

        # Y-plane
        ax2y.plot(passes, ey*1e6, color=colors[i], linestyle='--', linewidth=1.5, label=f"{config['label']}")
        ax3y.plot(passes, Cy*1e6, color=colors[i], linestyle='--', linewidth=1.5, label=f"{config['label']}")
        ax4y.plot(passes, Sy*1e3, color=colors[i], linestyle='--', linewidth=1.5, label=f"{config['label']}")

        ax5.plot(passes, Ss*1e3, color=colors[i], linestyle='-', linewidth=1.5, label=f"{config['label']}")
        
        ax6.plot(passes, Particles, color=colors[i], linestyle='-', linewidth=1.5, label=f"{config['label']}")

        ax7.plot(passes, Sdelta*1e3, color=colors[i], linestyle='-', linewidth=1.5, label=f"{config['label']}")


    # --- Finalize Figures ---
    ax1.set_title('VPostBeam vs Pass')
    ax1.set_xlabel('Pass')
    ax1.set_ylabel('Cav1 FM VPostBeam (V)')
    ax1.grid(False)
    ax1.legend(loc='best')
    #ax1.set_ylim(9900,10000)
    fig1.savefig(os.path.join(output_dir, '1VPostBeam_Comparison.png'))
    print(f"Saved VPostBeam_Comparison.png to {output_dir}")

     # Emittance X/Y
    ax2x.set_title('Emittance X vs Pass')
    ax2x.set_xlabel('Pass')
    ax2x.set_ylabel('Emittance $\\epsilon_x$ ($\\mu$m-rad)')
    ax2x.grid(False)
    ax2x.legend(loc='best')
    fig2x.savefig(os.path.join(output_dir, '2EmittanceX_Comparison.png'))
    print(f"Saved 2EmittanceX_Comparison.png to {output_dir}")

    ax2y.set_title('Emittance Y vs Pass')
    ax2y.set_xlabel('Pass')
    ax2y.set_ylabel('Emittance $\\epsilon_y$ ($\\mu$m-rad)')
    ax2y.grid(False)
    ax2y.legend(loc='best')
    fig2y.savefig(os.path.join(output_dir, '2EmittanceY_Comparison.png'))
    print(f"Saved 2EmittanceY_Comparison.png to {output_dir}")

    # Centroid X/Y
    ax3x.set_title('Centroid X vs Pass')
    ax3x.set_xlabel('Pass')
    ax3x.set_ylabel('Centroid $C_x$ ($\\mu$m)')
    ax3x.grid(False)
    ax3x.legend(loc='best')
    fig3x.savefig(os.path.join(output_dir, '3CentroidX_Comparison.png'))
    print(f"Saved 3CentroidX_Comparison.png to {output_dir}")

    ax3y.set_title('Centroid Y vs Pass')
    ax3y.set_xlabel('Pass')
    ax3y.set_ylabel('Centroid $C_y$ ($\\mu$m)')
    ax3y.grid(False)
    ax3y.legend(loc='best')
    fig3y.savefig(os.path.join(output_dir, '3CentroidY_Comparison.png'))
    print(f"Saved 3CentroidY_Comparison.png to {output_dir}")

    # Beam Size X/Y
    ax4x.set_title('Beam Size X vs Pass')
    ax4x.set_xlabel('Pass')
    ax4x.set_ylabel(r'Beam Size $\sigma_x$ (mm)')
    ax4x.grid(False)
    ax4x.legend(loc='best')
    fig4x.savefig(os.path.join(output_dir, '4BeamSizeX_Comparison.png'))
    print(f"Saved 4BeamSizeX_Comparison.png to {output_dir}")

    ax4y.set_title('Beam Size Y vs Pass')
    ax4y.set_xlabel('Pass')
    ax4y.set_ylabel(r'Beam Size $\sigma_y$ (mm)')
    ax4y.grid(False)
    ax4y.legend(loc='best')
    fig4y.savefig(os.path.join(output_dir, '4BeamSizeY_Comparison.png'))
    print(f"Saved 4BeamSizeY_Comparison.png to {output_dir}")


    ax5.set_title('RMS Bunch Length vs Pass')
    ax5.set_xlabel('Pass')
    ax5.set_ylabel(r'RMS Bunch Length $\sigma_s$ (mm)')
    ax5.grid(False)
    ax5.legend(loc='right')
    fig5.savefig(os.path.join(output_dir, '5BunchLength_Comparison.png'))
    print(f"Saved BunchLength_Comparison.png to {output_dir}")
    
    ax6.set_title('Particles vs Pass')
    ax6.set_xlabel('Pass')
    ax6.set_ylabel('Number of Particles')
    ax6.grid(False)
    ax6.legend(loc='lower right', ncol=2)
    fig6.savefig(os.path.join(output_dir, '6Particles_Comparison.png'))
    print(f"Saved Particles_Comparison.png to {output_dir}")

    ax7.set_title('RMS Momentum Spread vs Pass')
    ax7.set_xlabel('Pass')
    ax7.set_ylabel(fr'RMS Momentum Spread $\sigma_\delta (10^-3$)')
    ax7.grid(False)
    ax7.legend(loc='right')
    fig7.savefig(os.path.join(output_dir, '7MomentumSpread_Comparison.png'))
    print(f"Saved MomentumSpread_Comparison.png to {output_dir}")

    # Display the plots
    plt.show()

if __name__ == "__main__":
    main()
