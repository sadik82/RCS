#!/bin/bash
rm *.png
sddsplot BARtoRCSr.wParam \
  -layout=3,3 \
  -col=Pass,pAverage -newPanel=1,1 \
  -col=Pass,Cx -legend=specified="x" -newPanel=1,2 -col=Pass,Cy -legend=specified="y" -graphic=line,type=1 \
  -col=Pass,Cxp -legend=specified="x" -newPanel=1,3 -col=Pass,Cyp -legend=specified="y" -graphic=line,type=1 \
  -col=Pass,ex -newPanel=2,1 -col=Pass,ey -graphic=line,type=1 \
  -col=Pass,Sxp -legend=specified="x" -newPanel=2,2 -col=Pass,Syp -legend=specified="y" -graphic=line,type=1 \
  -col=Pass,Sx -legend=specified="x" -newPanel=2,3 -col=Pass,Sy -legend=specified="y" -graphic=line,type=1 \
  -col=Pass,Ss -newPanel=3,1 \
  -col=Pass,Cdelta -newPanel=3,2 \
  -col=Pass,Sdelta -newPanel=3,3 \
  -device=png -output=4_RCS_591MHz_V3_wParam_NoHOMs.png

  sddsplot BARtoRCSr.wParam -col=Pass,Cx -legend=specified="x" -col=Pass,Cy -legend=specified="y" -graphic=line,type=1 -device=png -output=3_RCS_591MHz_V3_LongModesOnly_CxCy_NoHOMs.png
  sddsplot BARtoRCSr.wParam -col=Pass,Cxp -legend=specified="x" -col=Pass,Cyp -legend=specified="y" -graphic=line,type=1 -device=png -output=3_RCS_591MHz_V3_LongModesOnly_CxpCyp_NoHOMs.png
  sddsplot BARtoRCSr.wParam -col=Pass,ex -newPanel=2,1 -col=Pass,ey -graphic=line,type=1 -device=png -output=3_RCS_591MHz_V3_LongModesOnly_exey_NoHOMs.png
  sddsplot BARtoRCSr.wParam -col=Pass,Sxp -legend=specified="x" -col=Pass,Syp -legend=specified="y" -graphic=line,type=1 -device=png -output=3_RCS_591MHz_V3_LongModesOnly_SxpSyp_NoHOMs.png
  sddsplot BARtoRCSr.wParam -col=Pass,Sx -legend=specified="x" -col=Pass,Sy -legend=specified="y" -graphic=line,type=1 -device=png -output=3_RCS_591MHz_V3_LongModesOnly_SxSy_NoHOMs.png
  sddsplot BARtoRCSr.wParam -col=Pass,Ss -newPanel=3,1 -device=png -output=3_RCS_591MHz_V3_LongModesOnly_Ss_NoHOMs.png
  sddsplot BARtoRCSr.wParam -col=Pass,Cdelta -newPanel=3,2 -device=png -output=3_RCS_591MHz_V3_LongModesOnly_Cdelta.png
  sddsplot BARtoRCSr.wParam -col=Pass,Sdelta -newPanel=3,3 -device=png -output=3_RCS_591MHz_V3_LongModesOnly_Sdelta_NoHOMs.png


sddsplot BARtoRCSr.wParam \
  -layout=3,2 \
  -col=Pass,Cx -legend=specified="x" -newPanel=1,1 -col=Pass,Cy -legend=specified="y" -graphic=line,type=1 \
  -col=Pass,ex -newPanel=1,2 -col=Pass,ey -graphic=line,type=1 \
  -col=Pass,Sx -legend=specified="x" -newPanel=2,1 -col=Pass,Sy -legend=specified="y" -graphic=line,type=1 \
  -col=Pass,Ss -newPanel=2,2 \
  -col=Pass,Cdelta -newPanel=3,1 \
  -col=Pass,Sdelta -newPanel=3,1 \
  -device=png -output=5_RCS_591MHz_V3_wPara_NoHOMs.png

sddsplot BARtoRCSr.wParam -col=Pass,Particles -device=png -output=2_RCS_591MHz_LM_QL2e5_ParticleLoss.png

mkdir 1_NoHOMs_24kPass
scp cav* *.png *hist *.wParam *.out *.sdds 1_NoHOMs_24kPass

#./b_VHOM_sddsplot.sh  
# sddsplot RfRamp.sdds -column=time,Voltage -graph=line,primary -color=red RfRamp.sdds -column=time,Voltage -graph=line,secondary -color=blue -scale=0,0,0,0,0,0,0,0 -split=page -separate=page
  
# sddsplot RfRamp.sdds -columnNames=time,Voltage -graph=line,vary -legend -columnNames=time,Phase -graph=line,vary -scale=0,0,0,0,0,0,0,0 -split=page -separate=page -yScalesGroup=id=Phase -legend