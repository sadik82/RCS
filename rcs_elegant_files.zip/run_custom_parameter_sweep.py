#!/usr/bin/env python3
"""
Custom Parameter Sweep Script for BARtoRCSr_5GeV.ele
This script runs the specific 8 parameter combinations requested by the user
"""

import os
import subprocess
import shutil
import time
from pathlib import Path
import logging

def setup_logging():
    """Setup logging configuration"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('custom_parameter_sweep.log'),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)

def modify_ele_inplace(ele_file_path: str, sigma_s: float, sigma_dp: float) -> tuple[bool, str]:
    """Modify the given .ele file in-place and return (ok, original_contents)."""
    try:
        with open(ele_file_path, 'r') as f:
            original = f.read()

        lines = original.split('\n')
        for i, line in enumerate(lines):
            if 'sigma_s=' in line and 'sigma_dp=' in line and not line.strip().startswith('!'):
                lines[i] = f"    sigma_s={sigma_s}, sigma_dp={sigma_dp},"
                break

        with open(ele_file_path, 'w') as f:
            f.write('\n'.join(lines))

        return True, original
    except Exception as e:
        logging.error(f"Error modifying .ele file in-place: {e}")
        return False, ''

def create_custom_plotting_script(sigma_s, sigma_dp, output_dir):
    """Create a customized plotting script with the correct directory name"""
    
    # Convert parameters to directory name format
    sigma_s_mm = int(sigma_s * 1000)
    sigma_dp_str = f"{sigma_dp:.0e}".replace('e-0', 'e-')
    dir_name = f"3_5GeV_LRWON_RFONTRFON_SigdP{sigma_dp_str}_SigS{sigma_s_mm}mm"
    
    # Read the original plotting script
    with open('a1_BeamSddsPlot.sh', 'r') as f:
        content = f.read()
    
    # Replace the directory name in the script
    modified_content = content.replace(
        "mkdir 3_5GeV_LRWON_RFONTRFON_SigdP2e-3_SigS20mm",
        f"mkdir {dir_name}"
    ).replace(
        "scp cav* *.png *hist *.wParam *.out *.sdds 3_5GeV_LRWON_RFONTRFON_SigdP2e-3_SigS20mm",
        f"scp cav* *.png *hist *.wParam *.out *.sdds {dir_name}"
    )
    
    # Write the modified script
    temp_script = f"temp_plot_script_{int(time.time())}.sh"
    with open(temp_script, 'w') as f:
        f.write(modified_content)
    
    # Make it executable
    os.chmod(temp_script, 0o755)
    
    return temp_script, dir_name

def ensure_ramp_file(logger) -> bool:
    """Ensure Ramp_5_GeV_BucketHeight.sdds is in the working directory."""
    ramp_name = 'Ramp_5_GeV_BucketHeight.sdds'
    if os.path.exists(ramp_name):
        return True

    logger.info('Ramp file not found in CWD. Searching subdirectories...')
    try:
        for path in Path('.').rglob(ramp_name):
            try:
                shutil.copy2(str(path), '.')
                logger.info(f"Copied ramp file from {path}")
                return True
            except Exception as e:
                logger.error(f"Failed to copy ramp file from {path}: {e}")
                return False
    except Exception as e:
        logger.error(f"Error searching for ramp file: {e}")
        return False

    logger.error('Ramp_5_GeV_BucketHeight.sdds not found anywhere under this directory')
    return False

def run_simulation(ele_file, logger):
    """Run the Pelegant simulation"""
    cmd = ["mpirun", "-np", "12", "Pelegant", ele_file]
    logger.info(f"Running: {' '.join(cmd)}")
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)  # 1 hour timeout
        if result.returncode == 0:
            logger.info("Simulation completed successfully")
            return True
        else:
            logger.error(f"Simulation failed with return code {result.returncode}")
            logger.error(f"stderr: {result.stderr}")
            return False
    except subprocess.TimeoutExpired:
        logger.error("Simulation timed out after 1 hour")
        return False
    except Exception as e:
        logger.error(f"Error running simulation: {e}")
        return False

def run_plotting_script(script_path, logger):
    """Run the plotting script"""
    cmd = [f"./{script_path}"]
    logger.info(f"Running: {' '.join(cmd)}")
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)  # 5 minute timeout
        if result.returncode == 0:
            logger.info("Plotting completed successfully")
            return True
        else:
            logger.error(f"Plotting failed with return code {result.returncode}")
            logger.error(f"stderr: {result.stderr}")
            return False
    except subprocess.TimeoutExpired:
        logger.error("Plotting timed out after 5 minutes")
        return False
    except Exception as e:
        logger.error(f"Error running plotting script: {e}")
        return False

def cleanup_files():
    """Clean up temporary files"""
    files_to_remove = [
        "*.out", "*.wParam", "*.wCoord", "*.hist", "*.sdds", "*.png"
    ]
    
    for pattern in files_to_remove:
        try:
            for file in Path(".").glob(pattern):
                if file.is_file():
                    file.unlink()
        except Exception as e:
            logging.warning(f"Could not remove {pattern}: {e}")

def main():
    logger = setup_logging()
    
    # Define the specific parameter combinations
    parameter_combinations = [
        (0.04, 2.0e-3),  # 2. sigma_s=0.04, sigma_dp=2.0e-3
        (0.08, 2.0e-3),  # 3. sigma_s=0.08, sigma_dp=2.0e-3
        (0.01, 5.0e-3),  # 5. sigma_s=0.01, sigma_dp=5.0e-3
        (0.02, 5.0e-3),  # 6. sigma_s=0.02, sigma_dp=5.0e-3
        (0.04, 5.0e-3),  # 7. sigma_s=0.04, sigma_dp=5.0e-3
        (0.08, 5.0e-3),  # 8. sigma_s=0.08, sigma_dp=5.0e-3
    ]
    
    # We will not create per-run result directories.
    # Only a top-level summary file will be written in the current directory.
    
    total_runs = len(parameter_combinations)
    logger.info(f"Starting custom parameter sweep with {total_runs} combinations")
    
    run_counter = 0
    
    for sigma_s, sigma_dp in parameter_combinations:
        run_counter += 1
        
        # Create parameter-specific directory name
        sigma_s_mm = int(sigma_s * 1000)
        sigma_dp_str = f"{sigma_dp:.0e}".replace('e-0', 'e-')
        dir_name = f"SigS{sigma_s_mm}mm_SigdP{sigma_dp_str}"
        
        logger.info(f"Run {run_counter}/{total_runs}: sigma_s={sigma_s}, sigma_dp={sigma_dp}")
        logger.info(f"Directory: {dir_name}")
        
        # No per-run output directory creation; plotting script will manage outputs.

        try:
            # Modify the main .ele in-place so filenames match plotting expectations
            ele_path = "BARtoRCSr_5GeV.ele"
            ok, original_ele = modify_ele_inplace(ele_path, sigma_s, sigma_dp)
            if not ok:
                logger.error(f"Failed to modify .ele file for {dir_name}")
                continue
            
            # Ensure ramp file exists before running
            if not ensure_ramp_file(logger):
                logger.error('Skipping run due to missing Ramp_5_GeV_BucketHeight.sdds')
                continue

            # Run simulation
            if run_simulation(ele_path, logger):
                # Create and run customized plotting script (it handles its own directory/exports)
                temp_plot_script, plot_dir_name = create_custom_plotting_script(sigma_s, sigma_dp, Path('.'))
                
                try:
                    if run_plotting_script(temp_plot_script, logger):
                        # No additional copying; plotting script already saved files and organized directories.
                        pass

                    logger.info(f"Completed run {run_counter}/{total_runs}")
                finally:
                    # Clean up temporary plotting script
                    if os.path.exists(temp_plot_script):
                        os.remove(temp_plot_script)
                
            else:
                logger.error(f"Simulation failed for {dir_name}")
            
        finally:
            # Restore original .ele so template remains intact for next run
            try:
                if 'original_ele' in locals() and original_ele:
                    with open(ele_path, 'w') as f:
                        f.write(original_ele)
            except Exception as restore_err:
                logger.error(f"Failed to restore original .ele: {restore_err}")

            # Clean up generated artifacts for next run
            cleanup_files()
    
    logger.info("Custom parameter sweep completed")
    
    # Create summary
    summary_file = Path("results_summary.txt")
    with open(summary_file, 'w') as f:
        f.write("Custom Parameter Sweep Results Summary\n")
        f.write("=" * 50 + "\n")
        f.write(f"Total runs: {total_runs}\n")
        f.write(f"Completed at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        f.write("Parameter combinations:\n")
        for i, (sigma_s, sigma_dp) in enumerate(parameter_combinations, 1):
            f.write(f"  {i}. sigma_s={sigma_s}, sigma_dp={sigma_dp}\n")
        f.write("\nDirectories in current folder after runs:\n")
        for item in sorted(Path('.').iterdir()):
            if item.is_dir():
                f.write(f"  {item.name}\n")
    
    logger.info(f"Summary saved to: {summary_file}")

if __name__ == "__main__":
    main()
