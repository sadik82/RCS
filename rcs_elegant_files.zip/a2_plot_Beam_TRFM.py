import subprocess
import os
import numpy as np
import matplotlib.pyplot as plt
import io
import re

import matplotlib as mpl

import matplotlib as mpl
mpl.rcParams.update({
    'axes.titlesize': 18,
    'axes.labelsize': 18,
    'xtick.labelsize': 18,
    'ytick.labelsize': 18,
    'legend.fontsize': 18,
    'figure.constrained_layout.use': True,   # <-- key line
})



def run_command(working_dir, command):
    """Executes a local command in a specified directory and returns the output."""
    # Execute the command directly.
    # The 'cwd' argument changes the directory before running the command.
    # 'shell=True' is used to correctly interpret the command string with its arguments.
    result = subprocess.run(command, shell=True, capture_output=True, text=True, cwd=working_dir)
    
    # Check for errors
    if result.returncode != 0:
        print(f"--- ERROR ---")
        print(f"Command failed: '{command}'")
        print(f"In directory: '{working_dir}'")
        print(f"Stderr: {result.stderr}")
        print(f"Stdout: {result.stdout}")
        print(f"-------------")
        return None
        
    return result.stdout

def main():
    """
    Main function to execute the data processing and plotting.
    """
    # --- Configuration ---
    # This is the directory where the script is running, which is the correct top-level directory.
    linux_dir = os.getcwd() 
    output_dir = '0_compare_TRFM'
    os.makedirs(output_dir, exist_ok=True) # Create the output directory if it doesn't exist
    print(f"Working directory set to: {linux_dir}")
    print(f"Output will be saved to: {output_dir}")
    
    # Detune configurations (similar to the MATLAB struct)
    detune_configs = [
        #{'suffix': '_TRFMQL1e4', 'label': '1e4'},
        {'suffix': '_TRFMQL5e3', 'label': '5e3'},
        {'suffix': '_TRFMQL4e3', 'label': '4e3'},
        #{'suffix': '_TRFMQL2e3', 'label': '2e3'},
        {'suffix': '_TRFMQL1e3', 'label': '1e3'}
        #{'suffix': '_NoHOM_NoFM', 'label': 'FM Only'}
#        {'suffix': '_NoHOM_NoFM', 'label': 'W/O FM & HOM'}
]
    
    colors = ['b', 'r', 'g', 'm', 'c', 'k','darkorange', 'gold', 'slategray', 'indigo', 'dodgerblue', 'deepskyblue']
    #colors = ['k', 'slategray','b', 'dodgerblue', 'c', 'teal', 'r', 'darkorange', 'gold','brown','olive', 'g', 'm', 'indigo']
    #colors = ['k','b', 'c', 'r', 'gold', 'g', 'm', 'indigo', 'slategray', 'darkorange', 'dodgerblue','brown', 'teal','olive']

    # --- Create Figures ---
    fig1, ax1 = plt.subplots(figsize=(7, 5)) # VPostBeam
    fig1b, ax1b = plt.subplots(figsize=(7, 5)) # VPostBeam
    fig2, ax2 = plt.subplots(figsize=(7, 5)) # Emittance
    fig3, ax3 = plt.subplots(figsize=(7, 5)) # Centroid
    fig3b, ax3b = plt.subplots(figsize=(7, 5)) # Centroid
    fig4, ax4 = plt.subplots(figsize=(7, 5)) # Beam Size
    fig5, ax5 = plt.subplots(figsize=(7, 5)) # Bunch Length (Ss)
    fig6, ax6 = plt.subplots(figsize=(7, 5)) # Particles
    fig7, ax7 = plt.subplots(figsize=(7, 5)) # Momentum Spread (Sdelta)


    # --- Loop through configurations ---
    for i, config in enumerate(detune_configs):
        print(f"Processing configuration: {config['label']}...")
        
        # --- Command 1 for VPostBeam ---
        sdds_file1 = f"1_5GeV{config['suffix']}/C1TM1.sdds"
        cmd1 = f"sddsprintout {sdds_file1} -col=Vx -col=Vy"
        
        # --- Command 2 for Emittance and other parameters ---
        sdds_file2 = f"1_5GeV{config['suffix']}/BARtoRCSr_5GeV.wParam"
        cols = "-col=ex -col=ey -col=Cx -col=Cy -col=Sx -col=Sy -col=Ss -col=Sdelta -col=Particles"
        cmd2 = f"sddsprintout {sdds_file2} {cols}"

        # --- Execute commands and capture output ---
        v_output = run_command(linux_dir, cmd1)
        b_output = run_command(linux_dir, cmd2)

        if v_output is None or b_output is None:
            print(f"Skipping configuration '{config['label']}' due to a command error.")
            continue
            
        # --- Robust Parsing Logic ---
        try:
            # Parse two-column Vx, Vy data robustly
            v_lines = v_output.strip().split('\n')
            v_data_list = []
            v_current_row = []
            for line in v_lines:
                for word in line.strip().split():
                    try:
                        v_current_row.append(float(word))
                    except ValueError:
                        continue
                while len(v_current_row) >= 2:
                    v_data_list.append(v_current_row[:2])
                    v_current_row = v_current_row[2:]
            v_data = np.array(v_data_list)

            # For multi-column data, safely try to convert words to numbers
            b_lines = b_output.strip().split('\n')
            b_data_list = []
            current_row = []
            for line in b_lines:
                # Split the line into words
                for word in line.strip().split():
                    try:
                        # Try to convert a word to a number and add it
                        current_row.append(float(word))
                    except ValueError:
                        # If it fails, just ignore the word (e.g., "Printout", "---")
                        continue
                
                # If we have collected a full row of 9, save it and reset
                while len(current_row) >= 9:
                    b_data_list.append(current_row[:9])
                    current_row = current_row[9:]
            
            b_data = np.array(b_data_list)

            # Check if any data was successfully parsed
            if v_data.size == 0 or b_data.size == 0:
                print(f"Could not parse any valid data lines for {config['label']}.")
                print("Please check if the sdds files exist and are not empty.")
                continue

        except Exception as e:
            print(f"An unexpected error occurred during parsing for {config['label']}. Error: {e}")
            continue

        # Extract columns for clarity
        # Ensure we don't try to plot more data than we have for passes
        num_points = min(len(v_data), len(b_data))
        if num_points == 0: continue

        passes = np.arange(1, num_points + 1)
        Vx = v_data[:num_points, 0]
        Vy = v_data[:num_points, 1] 
        ex = b_data[:num_points, 0]
        ey = b_data[:num_points, 1]
        Cx = b_data[:num_points, 2]
        Cy = b_data[:num_points, 3]
        Sx = b_data[:num_points, 4]
        Sy = b_data[:num_points, 5]
        Ss = b_data[:num_points, 6]
        Sdelta = b_data[:num_points, 7]
        Particles = b_data[:num_points, 8]

        # --- Plotting ---
        ax1.plot(passes, Vx, color=colors[i], linestyle='-', linewidth=1.5, label=f"$V_x$, {config['label']}")
        ax1b.plot(passes, Vy, color=colors[i], linestyle='--', linewidth=1.5, label=f"$V_y$, {config['label']}")
        
        ax2.plot(passes, ex*1e6, color=colors[i], linestyle='-', linewidth=1.5, label=f"$\\epsilon_x$, {config['label']}")
        ax2.plot(passes, ey*1e6, color=colors[i], linestyle='--', linewidth=1.5, label=f"$\\epsilon_y$, {config['label']}")

        ax3.plot(passes, Cx*1e6, color=colors[i], linestyle='-', linewidth=1.5, label=f"$C_x$, {config['label']}")
        ax3b.plot(passes, Cy*1e6, color=colors[i], linestyle='--', linewidth=1.5, label=f"$C_y$, {config['label']}")

        ax4.plot(passes, Sx*1e3, color=colors[i], linestyle='-', linewidth=1.5, label=f"$\\sigma_x$, {config['label']}")
        ax4.plot(passes, Sy*1e3, color=colors[i], linestyle='--', linewidth=1.5, label=f"$\\sigma_y$, {config['label']}")

        ax5.plot(passes, Ss*1e3, color=colors[i], linestyle='-', linewidth=1.5, label=f"$\\sigma_s$, {config['label']}")
        
        ax6.plot(passes, Particles, color=colors[i], linestyle='-', linewidth=1.5, label=f"{config['label']}")

        ax7.plot(passes, Sdelta*1e3, color=colors[i], linestyle='-', linewidth=1.5, label=f"$\\delta$, {config['label']}")


    # --- Finalize Figures ---
    ax1.set_title('V$_{x}$ vs Pass')
    ax1.set_xlabel('Pass')
    ax1.set_ylabel('Vx (V)')
    ax1.grid(False)
    ax1.legend(loc='best')
    fig1.savefig(os.path.join(output_dir, '1Vx_Comparison.png'))
    print(f"Saved Vx_Comparison.png to {output_dir}")

    ax1b.set_title('V$_{y}$ vs Pass')
    ax1b.set_xlabel('Pass')
    ax1b.set_ylabel('Vy (V)')
    ax1b.grid(False)
    ax1b.legend(loc='best')
    fig1b.savefig(os.path.join(output_dir, '1Vy_Comparison.png'))
    print(f"Saved Vy_Comparison.png to {output_dir}")

    ax2.set_title('Emittance vs Pass')
    ax2.set_xlabel('Pass')
    ax2.set_ylabel('Emittance ($\mu$m-rad)')
    ax2.grid(False)
    ax2.legend(loc='best')
    fig2.savefig(os.path.join(output_dir, '2Emittance_Comparison.png'))
    print(f"Saved Emittance_Comparison.png to {output_dir}")

    ax3.set_title('Centroid vs Pass')
    ax3.set_xlabel('Pass')
    ax3.set_ylabel('Centroid ($\mu$m)')
    ax3.grid(False)
    ax3.legend(loc='best')
    fig3.savefig(os.path.join(output_dir, '3Centroid_Comparison_x.png'))
    print(f"Saved Centroid_Comparison_x.png to {output_dir}")

    ax3b.set_title('Centroid vs Pass')
    ax3b.set_xlabel('Pass')
    ax3b.set_ylabel('Centroid ($\mu$m)')
    ax3b.grid(False)
    ax3b.legend(loc='best')
    fig3b.savefig(os.path.join(output_dir, '3Centroid_Comparison_y.png'))
    print(f"Saved Centroid_Comparison_y.png to {output_dir}")

    ax4.set_title('Beam Size vs Pass')
    ax4.set_xlabel('Pass')
    ax4.set_ylabel(r'Beam Size ($\sigma$) (mm)')
    ax4.grid(False)
    ax4.legend(loc='best')
    fig4.savefig(os.path.join(output_dir, '4BeamSize_Comparison.png'))
    print(f"Saved BeamSize_Comparison.png to {output_dir}")

    ax5.set_title('Bunch Length vs Pass')
    ax5.set_xlabel('Pass')
    ax5.set_ylabel(r'Bunch Length ($\sigma_s$) (mm)')
    ax5.grid(False)
    ax5.legend(loc='best')
    fig5.savefig(os.path.join(output_dir, '5BunchLength_Comparison.png'))
    print(f"Saved BunchLength_Comparison.png to {output_dir}")
    
    ax6.set_title('Particles vs Pass')
    ax6.set_xlabel('Pass')
    ax6.set_ylabel('Number of Particles')
    ax6.grid(False)
    ax6.legend(loc='lower right', ncol=2)
    fig6.savefig(os.path.join(output_dir, '6Particles_Comparison.png'))
    print(f"Saved Particles_Comparison.png to {output_dir}")

    ax7.set_title('Momentum Spread vs Pass')
    ax7.set_xlabel('Pass')
    ax7.set_ylabel(r'Momentum Spread ($\delta \times 10^3$)')
    ax7.grid(False)
    ax7.legend(loc='best')
    fig7.savefig(os.path.join(output_dir, '7MomentumSpread_Comparison.png'))
    print(f"Saved MomentumSpread_Comparison.png to {output_dir}")

    # Display the plots
    plt.show()

if __name__ == "__main__":
    main()
