import subprocess
import os
import numpy as np
import matplotlib.pyplot as plt
import io
import re

import matplotlib as mpl

import matplotlib as mpl
mpl.rcParams.update({
    'axes.titlesize': 18,
    'axes.labelsize': 18,
    'xtick.labelsize': 18,
    'ytick.labelsize': 18,
    'legend.fontsize': 18,
    'figure.constrained_layout.use': True,   # <-- key line
})

def run_command(working_dir, command):
    """Executes a local command in a specified directory and returns the output."""
    # Execute the command directly.
    # The 'cwd' argument changes the directory before running the command.
    # 'shell=True' is used to correctly interpret the command string with its arguments.
    result = subprocess.run(command, shell=True, capture_output=True, text=True, cwd=working_dir)
    
    # Check for errors
    if result.returncode != 0:
        print(f"--- ERROR ---")
        print(f"Command failed: '{command}'")
        print(f"In directory: '{working_dir}'")
        print(f"Stderr: {result.stderr}")
        print(f"Stdout: {result.stdout}")
        print(f"-------------")
        return None
        
    return result.stdout

def main():
    """
    Main function to execute the data processing and plotting.
    """
    # --- Configuration ---
    # This is the directory where the script is running, which is the correct top-level directory.
    linux_dir = os.getcwd() 
    output_dir = '0_compare_5GeV_LWON_SigdP_by_Sigs'
    os.makedirs(output_dir, exist_ok=True) # Create the output directory if it doesn't exist
    print(f"Working directory set to: {linux_dir}")
    print(f"Output will be saved to: {output_dir}")
    
    # Configuration for different SigdP values grouped by Sigs (bunch length)
    # Based on your folder structure, organizing by bunch length (Sigs) and momentum spread (SigdP)
    sigs_groups = {
        '5mm': [
            {'folder': '1_5GeV_LWON_SigdP5e-4_SigS5mm', 'sigdp': '5e-4', 'label': 'SigdP 5e-4'},
            {'folder': '1_5GeV_LWON_SigdP1e-3_SigS5mm', 'sigdp': '1e-3', 'label': 'SigdP 1e-3'},
            {'folder': '1_5GeV_LWON_SigdP2e-3_SigS5mm', 'sigdp': '2e-3', 'label': 'SigdP 2e-3'},
            {'folder': '1_5GeV_LWON_SigdP5e-3_SigS5mm', 'sigdp': '5e-3', 'label': 'SigdP 5e-3'}
        ],
        '10mm': [
            {'folder': '1_5GeV_LWON_SigdP5e-4_SigS10mm', 'sigdp': '5e-4', 'label': 'SigdP 5e-4'},
            {'folder': '1_5GeV_LWON_SigdP1e-3_SigS10mm', 'sigdp': '1e-3', 'label': 'SigdP 1e-3'},
            {'folder': '1_5GeV_LWON_SigdP2e-3_SigS10mm', 'sigdp': '2e-3', 'label': 'SigdP 2e-3'},
            {'folder': '1_5GeV_LWON_SigdP5e-3_SigS10mm', 'sigdp': '5e-3', 'label': 'SigdP 5e-3'}
        ],
        '20mm': [
            {'folder': '1_5GeV_LWON_SigdP5e-4_SigS20mm', 'sigdp': '5e-4', 'label': 'SigdP 5e-4'},
            {'folder': '1_5GeV_LWON_SigdP1e-3_SigS20mm', 'sigdp': '1e-3', 'label': 'SigdP 1e-3'},
            {'folder': '1_5GeV_LWON_SigdP2e-3_SigS20mm', 'sigdp': '2e-3', 'label': 'SigdP 2e-3'},
            {'folder': '1_5GeV_LWON_SigdP5e-3_SigS20mm', 'sigdp': '5e-3', 'label': 'SigdP 5e-3'}
        ],
        '40mm': [
            {'folder': '1_5GeV_LWON_SigdP5e-4_SigS40mm', 'sigdp': '5e-4', 'label': 'SigdP 5e-4'},
            {'folder': '1_5GeV_LWON_SigdP1e-3_SigS40mm', 'sigdp': '1e-3', 'label': 'SigdP 1e-3'},
            {'folder': '1_5GeV_LWON_SigdP2e-3_SigS40mm', 'sigdp': '2e-3', 'label': 'SigdP 2e-3'},
            {'folder': '1_5GeV_LWON_SigdP5e-3_SigS40mm', 'sigdp': '5e-3', 'label': 'SigdP 5e-3'}
        ],
        '80mm': [
            {'folder': '1_5GeV_LWON_SigdP5e-4_SigS80mm', 'sigdp': '5e-4', 'label': 'SigdP 5e-4'},
            {'folder': '1_5GeV_LWON_SigdP1e-3_SigS80mm', 'sigdp': '1e-3', 'label': 'SigdP 1e-3'},
            {'folder': '1_5GeV_LWON_SigdP2e-3_SigS80mm', 'sigdp': '2e-3', 'label': 'SigdP 2e-3'},
            {'folder': '1_5GeV_LWON_SigdP5e-3_SigS80mm', 'sigdp': '5e-3', 'label': 'SigdP 5e-3'}
        ]
    }
    
    # Colors for different SigdP values
    sigdp_colors = {
        '5e-4': 'green',
        '1e-3': 'red',
        '2e-3': 'orange',
        '5e-3': 'blue'
    }
    
    # Line styles for different SigdP values
    sigdp_styles = {
        '5e-4': '-.',
        '1e-3': '-',
        '2e-3': ':',
        '5e-3': '--'
    }

    # Process each bunch length group
    for sigs_name, configs in sigs_groups.items():
        print(f"\nProcessing Sigs group: {sigs_name}")
        
        # --- Create Figures for this Sigs group ---
        fig1, ax1 = plt.subplots(figsize=(7, 5)) # VPostBeam
        fig2x, ax2x = plt.subplots(figsize=(7, 5)) # Emittance X
        fig2y, ax2y = plt.subplots(figsize=(7, 5)) # Emittance Y
        fig3x, ax3x = plt.subplots(figsize=(7, 5)) # Centroid X
        fig3y, ax3y = plt.subplots(figsize=(7, 5)) # Centroid Y
        fig4x, ax4x = plt.subplots(figsize=(7, 5)) # Beam Size X
        fig4y, ax4y = plt.subplots(figsize=(7, 5)) # Beam Size Y
        fig5, ax5 = plt.subplots(figsize=(7, 5)) # Bunch Length (Ss)
        fig6, ax6 = plt.subplots(figsize=(7, 5)) # Particles
        fig7, ax7 = plt.subplots(figsize=(7, 5)) # Momentum Spread (Sdelta)

        # --- Loop through SigdP configurations for this Sigs ---
        for config in configs:
            print(f"  Processing configuration: {config['label']} for Sigs {sigs_name}...")
            
            # Check if folder exists
            if not os.path.exists(config['folder']):
                print(f"    Warning: Folder {config['folder']} does not exist, skipping...")
                continue
            
            # --- Command 1 for VPostBeam ---
            sdds_file1 = f"{config['folder']}/cav1mod1.sdds"
            cmd1 = f"sddsprintout {sdds_file1} -col=VPostBeam"
            
            # --- Command 2 for Emittance and other parameters ---
            sdds_file2 = f"{config['folder']}/BARtoRCSr_5GeV.wParam"
            cols = "-col=ex -col=ey -col=Cx -col=Cy -col=Sx -col=Sy -col=Ss -col=Sdelta -col=Particles"
            cmd2 = f"sddsprintout {sdds_file2} {cols}"

            # --- Execute commands and capture output ---
            v_output = run_command(linux_dir, cmd1)
            b_output = run_command(linux_dir, cmd2)

            if v_output is None or b_output is None:
                print(f"    Skipping configuration '{config['label']}' due to a command error.")
                continue
                
            # --- Robust Parsing Logic ---
            try:
                # For single-column data, the simple parser is fine.
                v_lines = v_output.strip().split('\n')
                v_data_list = []
                for line in v_lines:
                    try:
                        v_data_list.append(float(line.strip()))
                    except ValueError:
                        continue
                v_data = np.array(v_data_list)

                # For multi-column data, safely try to convert words to numbers
                b_lines = b_output.strip().split('\n')
                b_data_list = []
                current_row = []
                for line in b_lines:
                    # Split the line into words
                    for word in line.strip().split():
                        try:
                            # Try to convert a word to a number and add it
                            current_row.append(float(word))
                        except ValueError:
                            # If it fails, just ignore the word (e.g., "Printout", "---")
                            continue
                    
                    # If we have collected a full row of 9, save it and reset
                    while len(current_row) >= 9:
                        b_data_list.append(current_row[:9])
                        current_row = current_row[9:]
                
                b_data = np.array(b_data_list)

                # Check if any data was successfully parsed
                if v_data.size == 0 or b_data.size == 0:
                    print(f"    Could not parse any valid data lines for {config['label']}.")
                    print("    Please check if the sdds files exist and are not empty.")
                    continue

            except Exception as e:
                print(f"    An unexpected error occurred during parsing for {config['label']}. Error: {e}")
                continue

            # Extract columns for clarity
            # Ensure we don't try to plot more data than we have for passes
            num_points = min(len(v_data), len(b_data))
            if num_points == 0: continue

            passes = np.arange(1, num_points + 1)
            V = v_data[:num_points]
            ex = b_data[:num_points, 0]
            ey = b_data[:num_points, 1]
            Cx = b_data[:num_points, 2]
            Cy = b_data[:num_points, 3]
            Sx = b_data[:num_points, 4]
            Sy = b_data[:num_points, 5]
            Ss = b_data[:num_points, 6]
            Sdelta = b_data[:num_points, 7]
            Particles = b_data[:num_points, 8]

            # Get color and line style for this SigdP
            color = sigdp_colors[config['sigdp']]
            linestyle = sigdp_styles[config['sigdp']]

            # --- Plotting ---
            ax1.plot(passes, V, color=color, linestyle=linestyle, linewidth=1.5, label=f"{config['label']}")
            
            # X-plane
            ax2x.plot(passes, ex*1e6, color=color, linestyle=linestyle, linewidth=1.5, label=f"{config['label']}")
            ax3x.plot(passes, Cx*1e6, color=color, linestyle=linestyle, linewidth=1.5, label=f"{config['label']}")
            ax4x.plot(passes, Sx*1e3, color=color, linestyle=linestyle, linewidth=1.5, label=f"{config['label']}")

            # Y-plane
            ax2y.plot(passes, ey*1e6, color=color, linestyle=linestyle, linewidth=1.5, label=f"{config['label']}")
            ax3y.plot(passes, Cy*1e6, color=color, linestyle=linestyle, linewidth=1.5, label=f"{config['label']}")
            ax4y.plot(passes, Sy*1e3, color=color, linestyle=linestyle, linewidth=1.5, label=f"{config['label']}")

            ax5.plot(passes, Ss*1e3, color=color, linestyle=linestyle, linewidth=1.5, label=f"{config['label']}")
            
            ax6.plot(passes, Particles, color=color, linestyle=linestyle, linewidth=1.5, label=f"{config['label']}")

            ax7.plot(passes, Sdelta*1e3, color=color, linestyle=linestyle, linewidth=1.5, label=f"{config['label']}")

        # --- Finalize Figures for this Sigs group ---
        sigs_output_dir = os.path.join(output_dir, f'Sigs_{sigs_name}')
        os.makedirs(sigs_output_dir, exist_ok=True)
        
        ax1.set_title(f'VPostBeam vs Pass (Sigs = {sigs_name})')
        ax1.set_xlabel('Pass')
        ax1.set_ylabel('Cav1 FM VPostBeam (V)')
        ax1.grid(False)
        ax1.legend(loc='best')
        fig1.savefig(os.path.join(sigs_output_dir, '1VPostBeam_Comparison.png'))
        print(f"  Saved 1VPostBeam_Comparison.png for Sigs {sigs_name}")

        # Emittance X/Y
        ax2x.set_title(f'Emittance X vs Pass (Sigs = {sigs_name})')
        ax2x.set_xlabel('Pass')
        ax2x.set_ylabel('Emittance $\\epsilon_x$ ($\\mu$m-rad)')
        ax2x.grid(False)
        ax2x.legend(loc='best')
        fig2x.savefig(os.path.join(sigs_output_dir, '2EmittanceX_Comparison.png'))
        print(f"  Saved 2EmittanceX_Comparison.png for Sigs {sigs_name}")

        ax2y.set_title(f'Emittance Y vs Pass (Sigs = {sigs_name})')
        ax2y.set_xlabel('Pass')
        ax2y.set_ylabel('Emittance $\\epsilon_y$ ($\\mu$m-rad)')
        ax2y.grid(False)
        ax2y.legend(loc='best')
        fig2y.savefig(os.path.join(sigs_output_dir, '2EmittanceY_Comparison.png'))
        print(f"  Saved 2EmittanceY_Comparison.png for Sigs {sigs_name}")

        # Centroid X/Y
        ax3x.set_title(f'Centroid X vs Pass (Sigs = {sigs_name})')
        ax3x.set_xlabel('Pass')
        ax3x.set_ylabel('Centroid $C_x$ ($\\mu$m)')
        ax3x.grid(False)
        ax3x.legend(loc='best')
        fig3x.savefig(os.path.join(sigs_output_dir, '3CentroidX_Comparison.png'))
        print(f"  Saved 3CentroidX_Comparison.png for Sigs {sigs_name}")

        ax3y.set_title(f'Centroid Y vs Pass (Sigs = {sigs_name})')
        ax3y.set_xlabel('Pass')
        ax3y.set_ylabel('Centroid $C_y$ ($\\mu$m)')
        ax3y.grid(False)
        ax3y.legend(loc='best')
        fig3y.savefig(os.path.join(sigs_output_dir, '3CentroidY_Comparison.png'))
        print(f"  Saved 3CentroidY_Comparison.png for Sigs {sigs_name}")

        # Beam Size X/Y
        ax4x.set_title(f'Beam Size X vs Pass (Sigs = {sigs_name})')
        ax4x.set_xlabel('Pass')
        ax4x.set_ylabel(r'Beam Size $\sigma_x$ (mm)')
        ax4x.grid(False)
        ax4x.legend(loc='best')
        fig4x.savefig(os.path.join(sigs_output_dir, '4BeamSizeX_Comparison.png'))
        print(f"  Saved 4BeamSizeX_Comparison.png for Sigs {sigs_name}")

        ax4y.set_title(f'Beam Size Y vs Pass (Sigs = {sigs_name})')
        ax4y.set_xlabel('Pass')
        ax4y.set_ylabel(r'Beam Size $\sigma_y$ (mm)')
        ax4y.grid(False)
        ax4y.legend(loc='best')
        fig4y.savefig(os.path.join(sigs_output_dir, '4BeamSizeY_Comparison.png'))
        print(f"  Saved 4BeamSizeY_Comparison.png for Sigs {sigs_name}")

        ax5.set_title(f'RMS Bunch Length vs Pass (Sigs = {sigs_name})')
        ax5.set_xlabel('Pass')
        ax5.set_ylabel(r'RMS Bunch Length $\sigma_s$ (mm)')
        ax5.grid(False)
        ax5.legend(loc='right')
        fig5.savefig(os.path.join(sigs_output_dir, '5BunchLength_Comparison.png'))
        print(f"  Saved 5BunchLength_Comparison.png for Sigs {sigs_name}")
        
        ax6.set_title(f'Particles vs Pass (Sigs = {sigs_name})')
        ax6.set_xlabel('Pass')
        ax6.set_ylabel('Number of Particles')
        ax6.grid(False)
        ax6.legend(loc='lower right')
        fig6.savefig(os.path.join(sigs_output_dir, '6Particles_Comparison.png'))
        print(f"  Saved 6Particles_Comparison.png for Sigs {sigs_name}")

        ax7.set_title(f'RMS Momentum Spread vs Pass (Sigs = {sigs_name})')
        ax7.set_xlabel('Pass')
        ax7.set_ylabel(fr'RMS Momentum Spread $\sigma_\delta (10^-3$)')
        ax7.grid(False)
        ax7.legend(loc='right')
        fig7.savefig(os.path.join(sigs_output_dir, '7MomentumSpread_Comparison.png'))
        print(f"  Saved 7MomentumSpread_Comparison.png for Sigs {sigs_name}")

        # Close figures to save memory
        plt.close(fig1)
        plt.close(fig2x)
        plt.close(fig2y)
        plt.close(fig3x)
        plt.close(fig3y)
        plt.close(fig4x)
        plt.close(fig4y)
        plt.close(fig5)
        plt.close(fig6)
        plt.close(fig7)

    print(f"\nAll plots saved to {output_dir}")

if __name__ == "__main__":
    main()